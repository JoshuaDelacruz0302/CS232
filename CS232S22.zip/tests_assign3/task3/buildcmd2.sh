#!/bin/bash
cmd="gcc -Wall -std=c11 mem_bug2.c -o mem_bug2"
executable="mem_bug2"
