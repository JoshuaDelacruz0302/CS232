#!/bin/bash
cmd="gcc -Wall -std=c11 mem_bug3.c -o mem_bug3"
executable="mem_bug3"
