#!/bin/bash
cmd="gcc -Wall -std=c11 arith_until.c -o arith_until"
executable="arith_until"
