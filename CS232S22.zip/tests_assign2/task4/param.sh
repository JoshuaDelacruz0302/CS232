#!/bin/bash
expected="prime_test_buggy.c"
