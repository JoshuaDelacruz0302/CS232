#!/bin/bash
cmd="make"
executable="construct_3_structs_add"
