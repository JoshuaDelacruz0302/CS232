#!/bin/bash
chmod 755 ./*.sh
./testit1.sh
./testit2.sh
