chmod 755 *.sh
./buildit1.sh
./buildit2.sh
