#!/bin/bash
expected="Makefile mystring.c mystring.h mystring-test.c"
