#!/bin/bash
expected="construct_3.c"
