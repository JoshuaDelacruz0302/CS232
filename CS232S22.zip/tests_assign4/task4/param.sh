#!/bin/bash
expected="bubble.c"
